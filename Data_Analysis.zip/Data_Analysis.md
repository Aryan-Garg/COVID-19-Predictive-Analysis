<h1 style="text-align:center">COVID-19 Data Analysis & Visualization</h1>
<h3 style="text-align:center">Aryan Garg</h3>
<h4 style="text-align:center">B19153, Indian Institiute of Technology, Mandi</h4>
<h4 style="text-align:center"><a href="https://github.com/Aryan-Garg">Github</a> | <a href='b19153@students.iitmandi.ac.in'>E-Mail</a></h4>
<br>
<h4>Introduction:</h4>
<p> This document is solely made for educational purposes.<br><br>
    The <em>aim</em> of this document is to visualize COVID-19's statistics from 30th Jan to 8th June, mainly for India, to draw observations, inferences and answer some pressing questions relating to the pandemic.<br><br>
    Data visualization and it's analysis might give us some useful insights to create predictive models which might be of use to the general masses.<br>
</p>
<h4>Sources Used:</h4>
<ul>
    <li><a href="https://api.covid19india.org/csv/">API-Covid19-India</a></li>
    <li><a href="https://www.worldometers.info/coronavirus/#countries">Worldometers</a></li>
    <li><a href='https://censusindia.gov.in/Census_And_You/age_structure_and_marital_status.aspx'>Census of India</a></li>
<ul>


```python
# Loading Dataset and essential python libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

country_data = pd.read_csv("case_time_series.csv")
state_data = pd.read_csv("state_wise_daily.csv")

country_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Daily Confirmed</th>
      <th>Total Confirmed</th>
      <th>Daily Recovered</th>
      <th>Total Recovered</th>
      <th>Daily Deceased</th>
      <th>Total Deceased</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>30-Jan</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>31-Jan</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01-Feb</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>02-Feb</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>03-Feb</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
state_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Status</th>
      <th>TT</th>
      <th>AN</th>
      <th>AP</th>
      <th>AR</th>
      <th>AS</th>
      <th>BR</th>
      <th>CH</th>
      <th>CT</th>
      <th>...</th>
      <th>PB</th>
      <th>RJ</th>
      <th>SK</th>
      <th>TN</th>
      <th>TG</th>
      <th>TR</th>
      <th>UP</th>
      <th>UT</th>
      <th>WB</th>
      <th>UN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>14-Mar-20</td>
      <td>Confirmed</td>
      <td>81</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>12</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>14-Mar-20</td>
      <td>Recovered</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>14-Mar-20</td>
      <td>Deceased</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15-Mar-20</td>
      <td>Confirmed</td>
      <td>27</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>15-Mar-20</td>
      <td>Recovered</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 41 columns</p>
</div>



<h2>Timeline Analysis:</h2>


```python
# Total cases (actual and logarithmic scale)
x1 = country_data['Date']
y1 = country_data['Total Confirmed']


fig = plt.figure(figsize=(8,7))

plt.style.use('default')

# Actual -> subplot
plt.subplot(2,1,1) 
plt.title("Timeline of Total Confirmed Cases")

plt.ylabel("Total Confirmed Cases")

plt.tick_params(
    axis='x',         
    which='both',      
    bottom=False,             
    labelbottom=False)

plt.plot(x1[::5], y1[::5], 'orange', marker ='o', lw = 3)

# Logarithmic -> Subplot
plt.subplot(2,1,2)
plt.title("Timeline of Total Confirmed Cases (logarithmic)")
plt.xlabel("Dates")
plt.ylabel("Total Confirmed Cases")

plt.yscale('log')
plt.xticks(rotation = 60)
plt.plot(x1[::5],y1[::5], 'orange', marker='o', lw = 3)

plt.subplots_adjust(hspace=0.2)

plt.show()
```


![png](output_4_0.png)



```python
# Total deceased (actual and logarithmic scale)
y2 = country_data['Total Deceased']


fig = plt.figure(figsize=(8,7))

plt.style.use('default')

# Actual -> subplot
plt.subplot(2,1,1) 
plt.title("Timeline of Total Deceased")

plt.ylabel("Total Deceased")

plt.tick_params(
    axis='x',         
    which='both',      
    bottom=False,             
    labelbottom=False)

plt.plot(x1[::5], y2[::5], 'red', marker ='o', lw = 3)

# Logarithmic -> Subplot
plt.subplot(2,1,2)
plt.title("Timeline of Total Deceased (logarithmic)")
plt.xlabel("Dates")
plt.ylabel("Total Deceased")

plt.yscale('log')
plt.xticks(rotation = 60)
plt.plot(x1[::5],y2[::5], 'red', marker='o', lw = 3)

plt.subplots_adjust(hspace=0.2)

plt.show()
```


![png](output_5_0.png)



```python
# Deaths per 100 confirmed cases
# y1 -> total confirmed cases
# y2 -> total deceased

deathsPerHundred = []

for i in range(len(y1)):
    thisDate = (y2[i]*100.0) / y1[i]
    deathsPerHundred.append(thisDate)
    
fig = plt.figure(figsize=(8,3))

plt.style.use('default')

plt.title("Timeline: Total Deceased / 100 Cases")

plt.ylabel("Deceased / 100")
plt.xlabel("Dates")

plt.xticks(rotation=60)

plt.plot(x1[::5], deathsPerHundred[::5], 'r--', marker ='x', lw = 1)


plt.show()
```


![png](output_6_0.png)


<strong>Inferences/Observations/Questions That Arise:</strong>
<p>
<ol>
<li>To say that the infection spread is slowing would be wrong by looking solely at this ( Deceased / 100 cases ) graph because total confirmed cases are rising exponentially, but slower than some other countries like Brazil, USA, China.</li>
<br>
<li>The rates for total deceased/100 have stabilized. Are people naturally developing immunity against the virus? Or people who are getting infected more than once are also included in the data who have some antibodies which are able to cope up with the virus? (A question for medical sciences)</li>
<br>
<li> The lockdown has certainly the rate of cases in India and hence the deceased per 100 rates have stabilized. (But this can't be totally true because of inefficient testing in India) <br></li>
<br>
<li> Could there be a huge spike again? Just like there was at 10th March, 25th March, 5th April because the lockdown is lifted again and maybe the virus has evolved due to the new asymptomatic cases? <br></li> 
<br>
    <li> <em>Hypothesis</em>: To say that India is coping up with the virus implies better recovery rates. So, let's analyse those stats next... <br></li>
</ol>     
</p>


```python
# Total Recovered (Actual and logarithmic)
y3 = country_data['Total Recovered']

fig = plt.figure(figsize=(8,7))

plt.style.use('default')

# Actual -> subplot
plt.subplot(2,1,1) 
plt.title("Timeline of Total Recovered")

plt.ylabel("Total Recovered")

plt.tick_params(
    axis='x',         
    which='both',      
    bottom=False,             
    labelbottom=False)

plt.plot(x1[::5], y2[::5], 'green', marker ='o', lw = 3)

# Logarithmic -> Subplot
plt.subplot(2,1,2)
plt.title("Timeline of Total Recovered (logarithmic)")
plt.xlabel("Dates")
plt.ylabel("Total Recovered")

plt.yscale('log')
plt.xticks(rotation = 60)
plt.plot(x1[::5],y2[::5], 'green', marker='o', lw = 3)

plt.subplots_adjust(hspace=0.2)

plt.show()

```


![png](output_8_0.png)



```python
# Recovered per 100 confirmed cases
# y1 -> total confirmed cases
# y3 -> total recovered

recoveredPerHundred = []

for i in range(len(y1)):
    thisDate = (y3[i]*100.0) / y1[i]
    recoveredPerHundred.append(thisDate)
    
fig = plt.figure(figsize=(8,3))
plt.style.use('default')

plt.title("Timeline: Total Recovered / 100 Cases")
plt.ylabel("Recovered / 100")
plt.xlabel("Dates")
plt.xticks(rotation=60)

plt.plot(x1[::5], recoveredPerHundred[::5], 'g--', marker ='o', lw = 1)

plt.show()
```


![png](output_9_0.png)


<h3>So hypothesis (5) could possibly be true.</h3>
<p>To get a better understanding... Let's see all three together (confirmed, deaths, recovered)</p>


```python
# Analyzing multiple stat together...
fig = plt.figure(figsize=(14,5))
plt.style.use('seaborn-whitegrid')
# Plotting total cases, total deceased, total recovered in one plot
plt.subplot(1,2,1)

plt.title("All actual total stats together")
plt.xlabel("Dates")
plt.xticks(rotation=60)
plt.plot(x1[::10],y1[::10],color='blue',label="total confirmed")
plt.plot(x1[::10],y2[::10],color='red',lw = 2.8,label="total deceased")
plt.plot(x1[::10],y3[::10],color='green',lw = 2.8,label="total recovered")
plt.legend()

# Plotting deaths/100 and recovered/100 together
plt.subplot(1,2,2)
plt.title("Death/100 vs Recovery/100")
plt.xlabel("Dates")
plt.ylabel("per 100 cases")
plt.xticks(rotation=60)
plt.plot(x1[::10], recoveredPerHundred[::10], 'g--', marker ='o', lw = 1, label="Deaths/100")
plt.plot(x1[::10], deathsPerHundred[::10], 'r--', marker ='x', lw = 1, label="Recovered/100")
plt.legend()


plt.show()
```


![png](output_11_0.png)


<h3>Some of the observations drawn uptil now:</h3>
<p>
<ol>
    <li>India has not reached it's peak yet. It can still be categorized as a nation in stage 3.</li>
    <br>
    <li>Cases and deaths are rising and so is the recovery of patients. But this still doesn't prove our hypothesis that states that India is coping up with the virus which implies better recovery rates because the number of cases, which are rising quicker, may at a point, outweigh the effects of recovery rates and the death rate might start catching upto the recovery rate.</li>
    <br>
</ol>
<h4>Now let's look at some daily new cases, deaths & recovered cases to assess the daily situation</h4>
</p>



```python
# Plotting (Bar charts) ***DAILY NEW*** cases, deaths and recovered cases
D_Confirmed = country_data['Daily Confirmed']
D_Deceased = country_data['Daily Deceased']
D_Recovered = country_data['Daily Recovered']

fig1 = plt.figure(figsize=(14,4))

plt.subplot(1,2,1)
plt.title("Daily New Deaths")
plt.xlabel("Dates")
plt.ylabel("Deaths")

plt.xticks(rotation=60)

plt.bar(x1[::7],D_Deceased[::7],align='edge',color='red')

plt.subplot(1,2,2)
plt.title("Daily New Recovered")
plt.xlabel("Dates")
plt.ylabel("Recovered")

plt.xticks(rotation=60)

plt.bar(x1[::7],D_Recovered[::7],align='edge',color='green')

fig2 = plt.figure(figsize=(14,3))

plt.title("Daily New Cases")
plt.xlabel("Dates")
plt.ylabel("Confirmed Cases")
plt.xticks(rotation=60)
plt.bar(x1[::3],D_Confirmed[::3],color='blue',align='edge')

plt.show()


```


![png](output_13_0.png)



![png](output_13_1.png)


<h3>Some numbers that might give us a perspective...</h3>
<p>
1)  No. of people recovered per one(new) death
<br>
2)  No. of people recovered per new case
<br>
3)  No. of deaths per new case
<br><br>
See these values in the next cells
</p>


```python
st1 = sum(D_Recovered) / sum(D_Deceased)
st2 = sum(D_Recovered) / sum(D_Confirmed)
st3 = sum(D_Deceased) / sum(D_Confirmed)

print("                 ***Averaged over",len(y1),"days of data***")
print("-----------------------------------------------------------------------")
print("Number of new recovered cases per one new death :  ",st1)
print("Number of new recovered cases per new case      :  ",st2)
print("Number of new deaths per new case               :  ",st3)
print("-----------------------------------------------------------------------")
```

                     ***Averaged over 131 days of data***
    -----------------------------------------------------------------------
    Number of new recovered cases per one new death :   17.318175738932727
    Number of new recovered cases per new case      :   0.4867585641735051
    Number of new deaths per new case               :   0.02810680359821217
    -----------------------------------------------------------------------
    

<h2>Is this, on average, same across the whole nation?</h2>


```python
abbrs = []
for col in state_data.columns:
    if len(col)==2:
        abbrs.append(col)
abbrs.remove('TT')


fulls = ['Andaman and Nicobar Islands','Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chandigarh','Chhattisgarh',
         'Dadra and Nagar Haveli','Daman and Diu','Delhi','Goa','Gujarat','Haryana','Himachal Pradesh','Jammu and Kashmir',
         'Jharkhand','Karnataka','Kerala','Lakshadweep','Ladakh','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland',
         'Odisha','Puducherry','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand',
         'West Bengal','Union Territories'
        ]


total_cases_st_wise = []
total_rcvd_st_wise = []
total_dead_st_wise = []

for st in abbrs:
    total_cases_st_wise.append(sum(state_data[st][0::3]))
    total_rcvd_st_wise.append(sum(state_data[st][1::3]))
    total_dead_st_wise.append(sum(state_data[st][2::3]))
fig = plt.figure(figsize=(7,10))
plt.style.use('fivethirtyeight')
plt.title("State wise total cases")
plt.barh(fulls,total_cases_st_wise)

plt.show()

```


![png](output_17_0.png)



```python
fig1 = plt.figure(figsize=(8,8))
plt.style.use('ggplot')
plt.title("State-wise total recovered")
plt.barh(fulls, total_rcvd_st_wise,color='green')
plt.show()
```


![png](output_18_0.png)



```python
fig2 = plt.figure(figsize=(8,8))
plt.style.use('ggplot')
plt.title("State-wise total deaths")
plt.barh(fulls, total_dead_st_wise)
plt.show()
```


![png](output_19_0.png)


<h2>Some Highly Populated States of India - 2016 Data (decreasing order):</h2>
<p>
    <pre>
 States | Total Pop.(2019 data) |  Pct 0-14yrs |  Pct 15-59yrs |  Pct >60yrs |
    <ol>
        <li>Uttar Pradesh  : 237,882,725 |    30.2%    |    62.8%   |   7.0%   |</li>
        <li>Bihar          : 124,799,926 |    35.0%    |    58.4%   |   6.6%   |</li>
        <li>Maharashtra    : 123,144,223 |    25.1%    |    65.6%   |   9.3%   |</li>
        <li>West Bengal    : 99,609,303  |    23.7%    |    67.4%   |   9.0%   |</li>
        <li>Madhya Pradesh : 85,358,965  |    30.1%    |    62.7%   |   7.2%   |</li>
        <li>Rajasthan      : 81,032,689  |    30.1%    |    62.4%   |   7.5%   |</li>
        <li>Tamil Nadu     : 77,841,267  |    21.6%    |    67.9%   |   10.5%  |</li>
        <li>Karnataka      : 67,562,686  |    24.3%    |    67.4%   |   8.3%   |</li>
        <li>Gujarat        : 63,872,399  |    26.1%    |    65.3%   |   8.6%   |</li>
        <li>Delhi          : 18,710,922  |    25.0%    |    68.1%   |   6.9%   |</li>
    </ol>
    </pre>
</p>
<p>
    Assuming one in five hundred gets infected.
    
    Q. Why this assmption? 
    A. Pop of india in (populated states) / Total cases in India
    
    It is quite evident that Pct[(0-14yrs) + (>60yrs)]*population_of that_state/500 = total cases in that state
    Implication >> children and elderly are at a higher risk...
</p>
<h3>Let's prove it by this data and code -> Case Study: Maharashtra</h3>


```python
pop_maha = 123144223
pct_children_maha = 25.1
pct_elders_maha = 9.3

LHS = ((pct_children_maha+pct_elders_maha)/100) * pop_maha / 500
RHS = total_cases_st_wise[-17]

print("Our assumption and calculation ->",LHS)
print('Real data available to us      ->',RHS)
print("This somewhat proves our implied statement. The data is bound to vary to a greater extent... We just got lucky :)")
```

    Our assumption and calculation -> 84723.22542400002
    Real data available to us      -> 88529
    This somewhat proves our implied statement. The data is bound to vary to a greater extent... We just got lucky :)
    

<pre>
----------------------------------------------------------------------------------------------------------------------
This implies that there might be a relation between infection/death rates and the age of a person!
<strong>Age-wise Analysis (Death share of each age-group in India)</strong>
----------------------------------------------------------------------------------------------------------------------
</pre>


```python
# Source: worldometers (India)
age_grps = ['18-44yrs','45-64yrs','65-74yrs','0-17yrs','75+yrs'] # in years
age_grps_deceased = [601, 3413, 3788, 9, 7419]
exp_tp = (0.12,0.12,0.12,0.12,0.12)
fig_pie = plt.figure()
plt.title("Share of deaths among age-groups")
plt.pie(age_grps_deceased,labels=age_grps,autopct='%1.1f%%',explode=exp_tp, shadow=True, startangle=120,radius=1.15,
        colors=['yellow','m','dodgerblue','black','r'])
plt.show()
```


![png](output_23_0.png)


<pre>
Conclusion:

1) Elderly are at the highest risk. And due to the joint family structures in India (contact structure in India),it 
might be difficult to contain the spread. (Please take good care of your elderly in your family if you're reading this)

</pre>

<br>
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
<p style="text-align:center"><em>We have analysed COVID-19 to quite an extent. But how does it compare with other epidemics?</em></p>
<h2 style="text-align:center"> CASE STUDY: H1N1 vs. COVID-19</h2>
<br>
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

<p>
    We will look at:
    <pre><ol>
        <li> Total cases for each virus
        <li> Total deaths for each virus
        <li> Mortality rate percentages
        <li> RO - Reproduction Number (No. of people infected from one infected individual)
    </ol>
    And compare which one was the deadlier epidemic by measuring mortality rates and 
    giving logical estimates of growth in medical sciences and technology. 
    </pre>
</p>


```python
# source: worldometer (link at the beginning)
corona_cases = 7235413
corona_deaths = 409508
corona_mortality = 1.38
corona_ro = 2.3

# source: CDC --- taking worst case of highest no. of infected and dead
h1n1_cases = 1.4 * 1000000000 # 1.4 billion
h1n1_deaths = 575400
h1n1_mortality = 0.02
h1n1_ro = 1.5

fig = plt.figure(figsize=(12,7))
plt.style.use('default')
plt.subplot(2,2,1)
plt.title("Total cases")
plt.bar(['COVID-19','H1N1'],[corona_cases, h1n1_cases],color='deepskyblue')

plt.subplot(2,2,2)
plt.title("Total Deaths")
plt.bar(['COVID-19','H1N1'],[corona_deaths, h1n1_deaths],color='indianred')

plt.subplot(2,2,3)
plt.title("Mortality rate percentage")
plt.bar(["COVID-19",'H1N1'], [corona_mortality, h1n1_mortality], color='seagreen')

plt.subplot(2,2,4)
plt.title("RO number")
plt.bar(["COVID-19",'H1N1'], [corona_ro, h1n1_ro], color='gold')
plt.show()
```


![png](output_27_0.png)


<strong>Conclusion:</strong>
Clearly COVID-19 seems to be more deadly considering the mortality rates, RO number and just compare how many have sadly left us (may God rest their souls, Amen) with so few being infected as compared to H1N1.
And considering the fact we were fairly early to detect that coronavirus was spreading... It is clearly the deadlier virus.

<em>Any suggestions or improvements are welcome. If you discover any error, please contact me about the same.</em>
